# Changelog

## [0.1.0-beta.8.1](https://github.com/flarum/flarum/compare/v0.1.0-beta.8...v0.1.0-beta.8.1)

### Fixed
- Prevent caching of JSON:API responses ([e2544a2](https://github.com/flarum/flarum/commit/e2544a2a223b8ab2fb9efe00036b755b6e2cd7e7))
